// Copyright (c) Microsoft Corporation. All rights reserved.
// Consts.cs

namespace DevTeam.Backend;

public class Consts
{
    public const string TopicName = "devteam";
}
