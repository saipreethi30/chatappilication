// Copyright (c) Microsoft Corporation. All rights reserved.
// Program.cs

using AutoGen.OpenAI.Sample;

Structural_Output.RunAsync().Wait();
